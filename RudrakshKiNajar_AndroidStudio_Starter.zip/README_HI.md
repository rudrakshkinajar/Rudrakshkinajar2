# Rudraksh Ki Najar — Android Studio शुरुआती प्रोजेक्ट

## आपकी चुनी हुई सेटिंग
- Android मोबाइल APK
- पूरी हिंदी UI
- सभी महत्वपूर्ण संकेतों के लिए Notification (अभी केवल टेस्ट नोटिफिकेशन)
- Black + Gold Premium थीम

## Android Studio में चलाने का तरीका
1. ZIP को Extract करें।
2. Android Studio → Open → `RudrakshKiNajar` फ़ोल्डर चुनें।
3. Gradle Sync पूरा होने दें (इंटरनेट आवश्यक)।
4. Android फोन में Developer options और USB debugging चालू करें।
5. फोन कनेक्ट करके Run दबाएँ।
6. APK बनाने के लिए: Build → Build Bundle(s) / APK(s) → Build APK(s)।

## अभी क्या काम करता है
- हिंदी डैशबोर्ड और तीन टैब
- Black + Gold UI
- उदाहरण स्कैन सिग्नल कार्ड
- Android 13+ पर Notification permission अनुरोध
- टेस्ट नोटिफिकेशन

## अभी क्या नहीं जुड़ा है
यह **starter MVP** है, पूरा लाइव ट्रेडिंग स्कैनर नहीं। कार्ड में दिए गए शेयर/स्कोर डेमो हैं।
लाइव NSE+BSE डेटा, ऐतिहासिक डेटाबेस, वास्तविक स्कोरिंग, FII/DII, डिलीवरी डेटा,
ऑप्शन OI, समाचार/कॉरपोरेट घोषणाएँ और रिमोट पुश अलर्ट जोड़ने के लिए अलग backend/API,
डेटा लाइसेंस/स्रोत, सर्वर और Firebase Cloud Messaging सेटअप चाहिए।

मुफ्त सार्वजनिक डेटा से पूरे NSE+BSE का लगातार रियल-टाइम कवरेज सुनिश्चित नहीं होता।
एक्सचेंज/डेटा प्रदाता की शर्तें मानें; अनधिकृत endpoints scrape या data redistribute न करें।

## अगला विकास चरण
1. अधिकृत delayed/EOD डेटा provider adapter
2. NSE+BSE symbol master और historical OHLCV database
3. unusual volume, delivery, price momentum, breakout/breakdown scoring engine
4. corporate announcements और public insider-disclosure parser
5. WorkManager periodic refresh + Firebase Cloud Messaging backend
6. historical backtesting और false-signal नियंत्रण

## सुरक्षा / जोखिम
- ऐप broker login/password नहीं मांगता।
- कोई auto-trading नहीं है।
- सार्वजनिक disclosures का विश्लेषण किया जा सकता है; गोपनीय/अवैध insider information नहीं।
- स्कोर संभाव्यता की गारंटी नहीं और खरीद/बिक्री सलाह नहीं है।
