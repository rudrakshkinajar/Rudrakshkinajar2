package com.rudrakshkinajar.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

private val Gold = Color(0xFFD4AF37)
private val Black = Color(0xFF101010)
private val Panel = Color(0xFF1D1D1D)
private val Muted = Color(0xFFB7B7B7)
private val Green = Color(0xFF45C486)
private val Red = Color(0xFFFF6B6B)

class MainActivity : ComponentActivity() {
    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { RudrakshApp(this) }
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "market_signals", "मार्केट संकेत", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "महत्वपूर्ण शेयर बाजार संकेत" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

data class MarketSignal(
    val symbol: String,
    val exchange: String,
    val direction: String,
    val score: Int,
    val reason: String
)

@Composable
fun RudrakshApp(context: Context) {
    var selectedTab by remember { mutableStateOf("डैशबोर्ड") }
    val signals = remember {
        listOf(
            MarketSignal("RELIANCE", "NSE", "तेजी पर नजर", 82, "वॉल्यूम औसत से अधिक — डेमो डेटा"),
            MarketSignal("TATAMOTORS", "NSE", "गिरावट पर नजर", 71, "कीमत कमजोर, वॉल्यूम बढ़ा — डेमो डेटा"),
            MarketSignal("SBIN", "NSE", "न्यूट्रल", 54, "अभी स्पष्ट ब्रेकआउट नहीं — डेमो डेटा"),
            MarketSignal("HDFCBANK", "NSE", "तेजी पर नजर", 68, "मॉमेंटम बेहतर — डेमो डेटा")
        )
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Black, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Black, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("डैशबोर्ड", "स्कैनर", "अलर्ट").forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Text(if (tab == "अलर्ट") "🔔" else if (tab == "स्कैनर") "⌕" else "⌂") },
                        label = { Text(tab) }
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("RUDRAKSH KI NAJAR", color = Gold, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("AI SMART MONEY SCANNER", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = {
                        postSignalNotification(context, "स्कैनर रीफ्रेश", "डेमो स्क्रीन: लाइव डेटा कनेक्ट नहीं है।")
                    }) { Icon(Icons.Default.Refresh, contentDescription = "रीफ्रेश", tint = Gold) }
                }
                Spacer(Modifier.height(18.dp))
                when (selectedTab) {
                    "डैशबोर्ड" -> {
                        Text("आज का बाजार", color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard("NIFTY 50", "डेटा प्रतीक्षारत", "लाइव फीड नहीं", Modifier.weight(1f))
                            MetricCard("BANK NIFTY", "डेटा प्रतीक्षारत", "लाइव फीड नहीं", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("महत्वपूर्ण संकेत", color = Gold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        SignalList(signals)
                    }
                    "स्कैनर" -> {
                        Text("सभी NSE / BSE शेयर", color = Gold, style = MaterialTheme.typography.titleMedium)
                        Text("यह शुरुआती UI है। असली स्कैन के लिए अधिकृत डेटा स्रोत/API जोड़ना बाकी है।", color = Muted)
                        Spacer(Modifier.height(12.dp))
                        SignalList(signals)
                    }
                    else -> {
                        Text("नोटिफिकेशन सेटिंग", color = Gold, style = MaterialTheme.typography.titleMedium)
                        Text("Android अनुमति मिलने पर ऐप स्थानीय टेस्ट नोटिफिकेशन दिखा सकता है। वास्तविक बाजार अलर्ट के लिए बैकएंड और FCM जोड़ना होगा।", color = Muted)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            postSignalNotification(context, "Rudraksh Ki Najar", "यह टेस्ट नोटिफिकेशन है। लाइव मार्केट संकेत अभी जुड़े नहीं हैं।")
                        }) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("टेस्ट नोटिफिकेशन भेजें")
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("ध्यान दें: स्क्रीन पर दिखाए गए शेयर और स्कोर केवल डेमो हैं, खरीद/बिक्री सलाह नहीं।", color = Muted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, note: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(note, color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun SignalList(signals: List<MarketSignal>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items(signals) { signal ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${signal.symbol}  ·  ${signal.exchange}", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(signal.direction, color = if (signal.direction.contains("गिरावट")) Red else Green)
                        Text(signal.reason, color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${signal.score}/100", color = Gold, fontWeight = FontWeight.Bold)
                        Text("डेमो", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

fun postSignalNotification(context: Context, title: String, message: String) {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val notification = NotificationCompat.Builder(context, "market_signals")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle(title)
        .setContentText(message)
        .setStyle(NotificationCompat.BigTextStyle().bigText(message))
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setAutoCancel(true)
        .build()
    manager.notify((System.currentTimeMillis() % 100000).toInt(), notification)
}
